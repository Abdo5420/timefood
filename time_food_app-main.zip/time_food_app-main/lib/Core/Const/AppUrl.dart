class AppUrls{
  static const String baseUrl = "https://time-food-api-production.up.railway.app/";
  static const String products = "api/products";
  static const String getAllrecipes = "api/recipes";
}