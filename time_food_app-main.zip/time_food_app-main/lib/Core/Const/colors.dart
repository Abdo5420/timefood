import 'dart:ui';
import 'package:flutter/material.dart';

Color cPrimaryColor = const Color(0xff39B748);
Color cSecondaryColor = const Color(0xff7d7f51);
Color cBackground = const Color(0xffe9e9dd);

